<!-- Page Footer-->
          <footer class="main-footer" style="background-color: #006F45">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Ilmu Komputer UNJ &copy; 2019</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Powered by <a href="https://bootstrapious.com/p/admin-template" class="external">Bootstrapious</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo base_url('assets/template/vendor') ?>/popper.js/umd/popper.min.js"> </script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/jquery.cookie/jquery.cookie.js"> </script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/jquery-validation/jquery.validate.min.js"></script>
    <!-- Main File-->
    <script src="<?php echo base_url(); ?>assets/template/js/front.js"></script>