
    <!-- main header -->
           <div class="page-content d-flex align-items-stretch"> 
 
<!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <!-- <div class="avatar"><img src="<?php //echo base_url(); ?>assets/template/img/user_black.png" alt="..." class="img-fluid rounded-circle"></div> -->
            <div class="title">
                <h1 class="h4">Welcome, </h1>
                <p>Pengguna Alumni</p>
            </div>
          </div>
          <ul class="list-unstyled">
        

        </nav>