  <!-- JavaScript files-->
    <script src="<?php echo base_url('assets/template/vendor') ?>/popper.js/umd/popper.min.js"> </script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/jquery.cookie/jquery.cookie.js"> </script>
    <script src="<?php echo base_url('assets/template/vendor') ?>/jquery-validation/jquery.validate.min.js"></script>
    <!-- Main File-->
    <script src="<?php echo base_url(); ?>assets/template/js/front.js"></script>