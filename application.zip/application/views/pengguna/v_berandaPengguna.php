  <!-- head -->
         <!-- Side Navbar -->
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Beranda</h2>
            </div>
          </header>

           <!-- Updates Section                                                -->
          <section class="updates padding-top">
            <div class="container-fluid">
              <div class="row">
                <!-- Recent Updates-->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header"><h5 class="card-title">Tracer Study Ilmu Komputer UNJ</h5>
                    </div>
                    <div class="card-body">
                      <div class="col-sm-12">
                        <center><img class="img-fluid" src="<?php echo base_url();?>/assets/template/img/wisuda.png ?>" alt="Card image cap" style="height: :270px;width:340px;margin-bottom: 15px"></center>
                      </div>
                      <p class="card-text" align="justify">Yth. Pengguna Alumni Ilmu Komputer FMIPA UNJ</p>
                      <p class="card-text" align="justify">Bapak/Ibu yang terhormat, saat ini kami sedang melakukan Tracer Study (penelusuran alumni) Program Studi Ilmu Komputer FMIPA-UNJ. Adapun tujuan dari kegiatan ini adalah untuk mendapatkan basis data yang diperlukan dalam penyusunan Evaluasi Diri dalam rangka Akreditasi Program Studi. Berkaitan dengan hal tersebut,  kami mohon Bapak/Ibu dapat mengisi kuesioner ini, data yang Bapak/Ibu isi dijamin kerahasiaannya. Untuk kerjasama dan bantuannya, kami mengucapkan banyak terima kasih. </p>
                    </div>
                  </div>
                </div>
                </div>
              </div>
          </section>
         

  </body>
</html>